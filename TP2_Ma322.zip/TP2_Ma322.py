# -*- coding: utf-8 -*-
"""
Created on Fri Mar 26 08:37:00 2021

@author: julien
"""

import numpy as np
from math import pi, cos, sin
import matplotlib.pyplot as plt

#-----------------------------------------------------------------------------
## SIMON Julien
## Aéro 3SC
## MA322 : Quadratures & Résolution numérique des équations diérentielles
## TP2 : Résolution numérique des équations diérentielles
#-----------------------------------------------------------------------------

#--------------------------------------------
## 4 Oscillations du pendule
#--------------------------------------------
#4.1 Résolution de l'équation linéarisée
#--------------------------------------------

#Constantes du problème
g = 9.81
L = 1
w0 = (g/L)**(1/2)
A = pi/2 # A = pi/15 pour la vérification des petis angles
h = 0.04 #pas
t = np.arange(0,4,h) #vecteur temps
N = len(t) #nombre de points

#Définition de la fonction de théta
def theta_t() :
    
    theta = []
    for k in range(N) :
        theta.append(A*cos(w0*t[k]))
    return (theta)


#--------------------------------------------
##4.2 Équation exacte
#--------------------------------------------
#4.2.1 Mise en equation : problème de Cauchy
#--------------------------------------------
#4.2.2 Résolution numérique de l'équation exacte, par la méthode d'Euler
#--------------------------------------------

Y0 = np.array([A,0])

#Définition de la fonction de pendule
def pendule(Y,t) :
    Y_prime = np.array([Y[1],-(w0**2)*sin(Y[0])])
    return(Y_prime)


#Définition de la méthode d'Euler explicit
def Euler_explicit(pendule,Y0,N,h) :
    Ye = np.zeros((N,Y0.size))
    Ye[0,:] = Y0
    
    for k in range(N-1) :
        Ye[k+1,:] = Ye[k,:] + h*pendule(Ye[k,:],t[k])
    return(Ye)


#--------------------------------------------
#4.2.3 Résolution numérique de l'équation exacte, par la méthode de Runge Kutta d'ordre 4
#--------------------------------------------

#Définition de la méthode de Runge Kutta d'ordre 4
def RK4(pendule,Y0,N,h) :
    Yrk = np.zeros((N,Y0.size))
    Yrk[0,:] = Y0
    
    for k in range(N-1) :
        k1 = pendule(Yrk[k,:],t[k])
        k2 = pendule(Yrk[k,:] + (h/2)*k1,t[k]+h/2)
        k3 = pendule(Yrk[k,:] + (h/2)*k2,t[k]+h/2)
        k4 = pendule(Yrk[k,:] + (h/2)*k3,t[k]+h/2)
        Yrk[k+1,:] = Yrk[k,:] + (h/6)*(k1 + 2*k2 + 2*k3 + k4)
    return(Yrk)


#--------------------------------------------
#4.2.4 Résolution numérique de l'équation exacte, avec le solveur odeint
#--------------------------------------------

from scipy.integrate import odeint

Yode = odeint(pendule,Y0,t)
    

#--------------------------------------------
#Tracés des différentes méthodes
#--------------------------------------------

def trace() :
    
    theta=theta_t()
    Ye = Euler_explicit(pendule,Y0,N,h)
    Yrk4 = RK4(pendule,Y0,N,h) 
    plt.plot(t,theta,label="theta théorique")
    plt.plot(t,Ye[:,0],label="Euler explicit")
    plt.plot(t,Yrk4[:,0],label="Runge Kutta d'ordre 4")
    plt.plot(t,Yode[:,0],label="Solveur odeint")
    plt.title("Tracé de theta en fonction du temps")
    plt.xlabel("Temps (s)")
    plt.ylabel("Angle (rad)")
    plt.legend()
    plt.show()
    
trace()

#-----------------------------------------------------------------------------

#--------------------------------------------
#5 Travail supplémentaire
#--------------------------------------------
#Portraits de phase
#--------------------------------------------

#Définition de la dérivée de théta
def theta_t_p() : #fonction theta(t)
    
    thetap = []
    for k in range(N) :
        thetap.append(-w0*A*sin(w0*t[k]))
    return (thetap)


def portrait() :
    
    theta=theta_t()
    thetap=theta_t_p()
    Ye = Euler_explicit(pendule,Y0,N,h)
    Yrk4 = RK4(pendule,Y0,N,h)
    plt.plot(theta,thetap,label="theta théorique")
    plt.plot(Ye[:,0],Ye[:,1],label="Euler explicit")
    plt.plot(Yrk4[:,0],Yrk4[:,1],label="Runge Kutta d'ordre 4")
    plt.plot(Yode[:,0],Yode[:,1],label="Solveur odeint")
    plt.title("Tracé des portraits de phases")
    plt.xlabel("theta (rad)")
    plt.ylabel("theta' (rad)")
    plt.legend()
    plt.show()

portrait()

#-----------------------------------------------------------------------------

#--------------------------------------------
#6 Suspension d'un véhicule
#--------------------------------------------
#6.3 Résolution numérique
#--------------------------------------------

#Constantes du problème
M1 = 15 
M2 = 200
C2 = 1200
K1 = 50000
K2 = 5000
ft = -1000

h2 = 0.03 #pas
tfin = 3 #temps final
t2 = np.arange(0,tfin,h2) #vecteur temps
N2 = len(t2) #nombre de points

#--------------------------------------------
#Conditions initiales
Y_ini = np.array([0,0,0,0])

#--------------------------------------------
#Définition de la fonction des suspensions
def suspension(Y,t2) :
    Yprime=np.array([Y[2], Y[3], (-1/M1)*((K1+K2)*Y[0]-K2*Y[1]+C2*Y[2]-C2*Y[3]), (-1/M2)*(-ft-K2*Y[0]+K2*Y[1]-C2*Y[2]+C2*Y[3])])
    return (Yprime)


#--------------------------------------------
#Résolution avec le solveur odeint

def solv_suspension(Y,t):  
    Yode = odeint(suspension, Y_ini, t2)
    x1_pp = Yode[:,0]
    x2_pp = Yode[:,1]
    plt.plot(t,x1_pp,label='x1(t)')
    plt.plot(t,x2_pp,label='x2(t)')
    return (x1_pp,x2_pp)

x1_pp,x2_pp = solv_suspension(Y_ini, t2)


#--------------------------------------------
#Tracé des variables x1 et x2

def trace2() :
    plt.title("Evolution de l'amortissement au cours du temps") 
    plt.xlabel('Temps (s)')
    plt.ylabel('Déplacement (m)')
    plt.legend()
    plt.show()
    
trace2()